import React from 'react';
import ReactDOM from 'react-dom';
import './index.css'; 
import LoginUi from './Login Ui/LoginUi';

ReactDOM.render( 
    <LoginUi /> ,
  document.getElementById('root')
);
 
